cluster.functions = makeClusterFunctionsMulticore(ncpus = getOption("mc.cores", 2L))
