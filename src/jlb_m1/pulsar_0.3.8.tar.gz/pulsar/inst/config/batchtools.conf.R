cluster.functions = makeClusterFunctionsInteractive()
