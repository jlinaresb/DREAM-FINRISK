cluster.functions = makeClusterFunctionsSocket(ncpus = getOption("mc.cores", 2L))
