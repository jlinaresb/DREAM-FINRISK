suppressPackageStartupMessages(library(testthat))
suppressPackageStartupMessages(library(pulsar))

testthat::test_check("pulsar")
